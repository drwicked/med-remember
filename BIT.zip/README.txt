                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2748353
BIT by Ferjerez is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Hi!

This time i made a printable version of 'BIT', first CGI character of 1982 movie TRON

https://www.youtube.com/watch?v=_fGujzulsas

There is 4 figures/states with their stands.
<ul>
<li>NO: Red Second stellation of icosahedron</li>
<li>YES: Yellow octahedron</li>
<li>IDLE 1: Blue Compound of icosahedron and dodecahedron</li>
<li>IDLE 2: Blue Small TriAmbic icosahedron</li>
</ul>

**About the files:**
For an easier print i've included some extra files:
**bit_yes_layflat.stl** : The octahedron laying in a face. You may need some infill to avoid gaps in the roof
**bit_no_half.stl**: Print two of this and use superglue to create the full stellated icosahedron. (no supports needed

Each stand fits with their corresponding figure. I've used a small ball of 'Blu-tack' to stick the stand and the figure. A bit of superglue will also work.

**Credits to:**
I've used some Opensad resources for the bit states:
Polyhedra in OpenSCAD: http://kitwallace.co.uk/3d/solid-index.xq (Generate Openscad files for lots of polyhedra)


The 59 stallations of icosahedron (WRL format): http://www.georgehart.com/virtual-polyhedra/stellations-icosahedron-index.html 

And one of the polyhedra found in https://www.thingiverse.com/thing:192584 

See below for some printing tips

Hope you enjoy it!
Have fun!



# Some tips

![Alt text](https://cdn.thingiverse.com/assets/3e/a4/fb/5f/5d/IMG_20180106_163720.jpg)
Use blu-tack or some sort of sticky gum

![Alt text](https://cdn.thingiverse.com/assets/b6/5a/4f/b6/ee/IMG_20180106_163733.jpg)

![Alt text](https://cdn.thingiverse.com/assets/ae/60/82/4b/dd/IMG_20180106_163759.jpg)
Fix!

![Alt text](https://cdn.thingiverse.com/assets/58/d0/47/08/e5/IMG_20180104_164600.jpg)
Print two of these and use glue for the stellated icosahedron (no supports needed)